﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escribe el primer numero");
            int num1 =Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Escribe el segundo numero");
            int num2 = Convert.ToInt32(Console.ReadLine());

            if(num1 >= num2)
            {
                Console.WriteLine("El primer numero es mayor o igual al segundo");
            }
            else
            {
                Console.WriteLine("El segundo numero es mayor que el primero");


                Console.ReadLine();
            }

        }
    }
}
