﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Escribe tu nombre");
            String nombre=Console.ReadLine();

            Console.WriteLine("Escribe tu edad");
            String texto= Console.ReadLine();

            int edad=Convert.ToInt32(texto);

            Console.WriteLine("Te llamas " + nombre + " y tienes " + edad + "años");

            Console.ReadLine();


        }
    }
}
