﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            int b = 30;
            int c = 4;

            int suma=a+b+c;

            Console.WriteLine("La suma es : "+ suma);
            Console.ReadLine();


         

        }
    
    }
}
