﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Escribe tu nombre");
            string nombre = Console.ReadLine();

            Console.WriteLine("Escribe tu ciudad");
            string ciudad = Console.ReadLine();

            Console.WriteLine("Hola " + nombre + "Bienvenido a " + ciudad);
            Console.ReadLine();
        }
    }
}
