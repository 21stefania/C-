# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy 
import pandas as pd
import openpyxl

archivo_excel="C:/Users/Estudiante/Downloads/python1.xlsx"
datos=pd.read_excel(archivo_excel)
print(datos)

maximo_poblacion=len(datos['Genero'])
print("El total de la poblacion es :",maximo_poblacion)

mujeres=sum(datos['Genero']=='F')
print("El total de la poblacion femenina :",mujeres)

hombres=sum(datos['Genero']=='M')
print("El total de la poblacion masculina :",hombres)

mujeres_porcentaje=mujeres/100
print("El porcentaje de mujeres es : ",mujeres_porcentaje,"%")

hombres_porcentaje=hombres/100
print("El porcentaje de hombres es : ",hombres_porcentaje,"%")

cali=sum(datos['Ciudad']=='Cali')
print("El total de caleños :",cali)

pasto=sum(datos['Ciudad']=='Pasto')
print("El total de pastusos :",pasto)

bogota=sum(datos['Ciudad']=='Bogota')
print("El total de Bogotanos :",bogota)

barranquilla=sum(datos['Ciudad']=='Barranquilla')
print("El total de Barranquilleros :",barranquilla)

Cartagena=sum(datos['Ciudad']=='Cartagena')
print("El total de cartageneros :",Cartagena)

medellin=sum(datos['Ciudad']=='Medellin')
print("El total de antioqueños :",medellin)

cucuta=sum(datos['Ciudad']=='Cucuta')
print("El total de cucuteños :",cucuta)

manizales=sum(datos['Ciudad']=='Manizales')
print("El total de manizalitas :",manizales)

maximo=max(datos['Salario'])
print("El salario mas alto es :",maximo)

minimo=min(datos['Salario'])
print("El salario mas bajo es :",minimo)

estrato=int(numpy.mean(datos['Estrato']))
print("La mayoria de las personas viven en estrato :" ,estrato)

edad=int(numpy.mean(datos['Edad']))
print("Promedio edad :" ,edad)

ganancias=float(sum(datos['Salario']))
print ("Cantidad total de ganancias de la poblacion :",ganancias)

documento=sum(datos['Telefono']==" ")
print(documento)











