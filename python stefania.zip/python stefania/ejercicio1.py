# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import numpy
import pandas as pd

archivo_excel="C:/Users/Estudiante/Downloads/nomina.xlsx"
datos=pd.read_excel(archivo_excel)
print(datos)
print(datos['NOMBRES'])


a=sum(datos['SALARIO'])
print("El total de todos los salarios es :",a)

b=max(datos['SALARIO'])
print("El salario max de los empleados es:",b)

c=min(datos['SALARIO'])
print('El salario min de los empleados es:',c)

d=numpy.mean(datos['SALARIO'])
print('El promedio de los salarios de los empleados es:',d)

e=len(datos)
print('Cuantos registros tiene el archivo:',e)

f=sum(datos['EPS'])
print("El total del saldo de eps es:",f)

g=sum(datos['PENSION'])
print("El total del saldo de pension es :",g)

h=sum(datos['FONDO SOLIDARIO'])
print("El total del saldo de fondo solidario es :",h)

i=sum(datos['OTROS DEDUCIDOS'])
print("El total de otros deducidos es :",i)

