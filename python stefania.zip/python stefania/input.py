# -*- coding: utf-8 -*-
"""
Created on Tue Apr 11 09:13:24 2023

@author: Estudiante
"""

"""Captura de datos"""

numero1=int(input("porfavor ingrese el valor 1:"))
numero2=int(input("porfavor ingrese el valor 2"))
suma=(numero1+numero2)
print(suma)

numero1=float(input("porfavor ingrese el valor 1:"))
numero2=float(input("porfavor ingrese el valor 2"))
suma=(numero1+numero2)
print(suma)
