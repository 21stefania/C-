# -*- coding: utf-8 -*-
"""
Created on Tue Apr 11 09:13:24 2023

@author: Estudiante
"""

"""Captura de datos"""


"""si juan gana 4.500.000 por treinta dias y trabaja
 solamente once dias cuanto devengaria ?
 cuanto le descuentan de eps, pension y cuanto recibe"""
 
salario=1500000

a=(salario/30)*11
 
print('el salario basico es', a)

if (salario>=2600000):
    print("su subsidio de transporte es igual a 0" )
    
else:
    print(a)

