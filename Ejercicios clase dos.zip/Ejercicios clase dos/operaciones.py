# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 09:15:47 2023

@author: Estudiante
"""

def menu():
    print("***MENU PRINCIPAL***")
    print("1-suma")
    print("2-resta")
    print("3-multiplicacion")
    print("4.division")
    print("5.salir")
    
opcionmenu=0
menu()

print("INGRESE LOS NUMEROS PARA HACER LA OPERACION")
numero1=int(input("Ingrese numero 1"))
numero2=int(input("Ingrese numero 2"))

while opcionmenu!=5:
    opcionmenu=int(input("digite la operacion matematica a realizar"))
    
    if opcionmenu==1:
        print("suma")
        print(numero1+numero2)
        
    elif opcionmenu==2:
        print("resta")
        print(numero1-numero2)
        
    elif opcionmenu==3:
        print("multiplicacion")
        print(numero1*numero2)
        
    elif opcionmenu==4:
        print("division")
        print(numero1/numero2)
        
    elif opcionmenu==5:
        print("salir")
      
        
    else:
        print("Opcion invalida digite una opcion una correcta")
        menu()