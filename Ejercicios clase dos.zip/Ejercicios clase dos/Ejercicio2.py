# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 09:42:53 2023

@author: Estudiante
"""

print("CONTRASEÑA")

contraseña=input("INGRESE SU CONTRASEÑA")
password="stefania"

if contraseña==password.lower():
    print("LA CONTRASEÑA ES CORRECTA :)")

else:
    print("LA CONTRASEÑA ES INCORRECTA INTENTE DE NUEVO")