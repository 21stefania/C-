# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 09:51:21 2023

@author: Estudiante
"""

print("TIENES QUE TRIBUTAR?")

edad=int(input("INGRESE SU EDAD"))
ingresos=int(input("DIGITE SUS INGRESOS MENSUALES"))


if edad>=16 and ingresos>= 1000:
    print("TIENES QUE TRIBUTAR")
    
else:
    print("NO TIENES QUE TRIBUTAR")
    