# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 08:52:07 2023

@author: Estudiante
"""


print('Calculemos tu edad')

nombre=input('Ingrese su nombre')
edad=int(input('Ingrese su edad'))

if edad >= 18:
        print(nombre,"Eres mayor de edad")

else:
       print("Eres menor de edad")