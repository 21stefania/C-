# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
print("********TIENDA DEPORTIVA MIS ZAPATOS Y YO******")
def menu():
    print("1.zapatos")
    print("2.sudaderas")
    print("3.implementos deportivos")
    print("4.accesorios")
    print("5.bicicletas")
    
opcionmenu=0
menu()

opcionmenu=(int(input("INGRESE EL NUMERO DEL ARTICULO QUE VA A LLEVAR")))



if opcionmenu==1:
    print("PRODUCTO: zapatos")
    valor1=100000
    print("valor 100000")
    cantidad=int(input("Ingresa cantidad:"))
    subtotal=cantidad*valor1
    print("CANTIDAD",cantidad)
    print("SUBTOTAL",subtotal)
    a1=(valor1*0.15)
   
    if (cantidad >5):
        print("DESCUENTO:",a1)
       
        iva=subtotal*0.19
        b1=subtotal-a1+iva
        print("NETO A PAGAR: ",b1)
    
    else:
       
        iva=subtotal*0.19
        print("IVA",iva)
        print("DESCUENTO 0")
        b1=subtotal-a1+iva
        print("NETO A PAGAR: ",b1)
         
        

elif opcionmenu==2:
    print("PRODUCTO: sudaderas")
    valor2=(int(input("Ingresa valor del producto")))
    cantidad=(int(input("Ingresa cantidad:")))
    a2=(valor1*0.2)
    if cantidad>=5:
        print("DESCUENTO:",a2)
    subtotal=(print(cantidad*valor2))
    iva=(print(valor2*0.19))
    neto=(print(subtotal-a2)+iva)
    
    
elif opcionmenu==3:
    print("PRODUCTO: implementos deportivos")
    valor3=(int(input("Ingresa valor del producto")))
    cantidad=(int(input("Ingresa cantidad:")))
    a3=(valor3*0.22)
    if cantidad>=5:
        print("DESCUENTO:",a3)
    subtotal=(print(cantidad*valor3))
    iva=(print(valor3*0.19))
    neto=(print(subtotal-a3)+iva)
    
    
elif opcionmenu==4:
    print("PRODUCTO: accesorios")
    valor4=(int(input("Ingresa valor del producto")))
    cantidad=(int(input("Ingresa cantidad:")))
    a4=(valor4*0.15)
    if cantidad>=5:
        print("DESCUENTO:",a4)
    subtotal=(print(cantidad*valor4))
    iva=(print(valor4*0.19))
    neto=(print(subtotal-a4)+iva)
    
    
elif opcionmenu==5:
    print("PRODUCTO: bicicletas")
    valor5=(int(input("Ingresa valor del producto")))
    cantidad=(int(input("Ingresa cantidad:")))
    a5=(valor5*0.15)
    if cantidad>=5:
        print("DESCUENTO:",a5)
    subtotal=(print(cantidad*valor5))
    iva=(print(valor5*0.19))
    neto=(print(subtotal-a5)+iva)
    